package com.example.shoeteccliente;

import com.google.gson.annotations.SerializedName;
public class Cliente {

    public Cliente(){}
    @SerializedName("id_cliente")
    private Long id_cliente;
    private String nombre;
    @SerializedName("direccion")
    private String direccion;
    private String localidad;
    private String provincia;
    private String email;
    private String telefono;
    private String password;

    // Constructor para Registro
    public Cliente(String nombre, String direccion, String localidad, String provincia, String email, String telefono, String password) {

        this.id_cliente = null;
        this.nombre = nombre;
        this.direccion = direccion;
        this.localidad = localidad;
        this.provincia = provincia;
        this.email = email;
        this.telefono = telefono;
        this.password = password;
    }

    // Constructor para Login
    public Cliente(String email, String password) {
        this.email = email;
        this.password = password;
    }
    public Long getIdCliente() { return id_cliente; }
    public void setIdCliente(Long id_cliente) { this.id_cliente = id_cliente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getLocalidad() { return localidad; }
    public void setLocalidad(String localidad) { this.localidad = localidad; }

    public String getProvincia() { return provincia; }
    public void setProvincia(String provincia) { this.provincia = provincia; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
