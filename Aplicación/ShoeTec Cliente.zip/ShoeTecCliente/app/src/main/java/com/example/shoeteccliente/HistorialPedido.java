package com.example.shoeteccliente;

import com.google.gson.annotations.SerializedName;

public class HistorialPedido {
    @SerializedName("id_pedido_fk")
    private Long id_pedido_fk;
    @SerializedName("id_historial")
    private Long id_historial;

    @SerializedName("estado")
    private String estado;

    @SerializedName("fecha")
    private String fecha;

    @SerializedName("completo")
    private boolean completo;

    // Constructor vacío obligatorio para GSON
    public Long getId_pedido_fk() {
        return id_pedido_fk;
    }

    public HistorialPedido() {
    }

    // Getters (El Adapter los usará para pintar los textos)
    public String getEstado() {
        return estado;
    }

    public String getFecha() {
        return fecha;
    }

    public Long getId_historial() {
        return id_historial;
    }

    public boolean getCompleto() {
        return completo;
    }

    // Setters
    public void setId_pedido_fk(Long id_pedido_fk) {
        this.id_pedido_fk = id_pedido_fk;
    }
    public void setEstado (String estado){
        this.estado = estado;
    }

    public void setFecha (String fecha){
            this.fecha = fecha;
    }
    public void setCompleto ( boolean completo){
            this.completo = completo;
    }
}
