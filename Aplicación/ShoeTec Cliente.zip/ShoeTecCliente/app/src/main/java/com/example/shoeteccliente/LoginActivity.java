package com.example.shoeteccliente;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {
    private CheckBox cbNuevoUsuario, cbLogueate;
    private TextView tvTituloPantalla;
    private Button btnHacerRegistro, btnHacerLogin;
    private LinearLayout containerRegistro, containerLogin;

    private EditText etRegNombre, etRegDireccion, etRegLocalidad, etRegTelefono, etRegEmail, etRegPassword;
    private EditText etRegProvincia;
    private CheckBox cbAceptoProteccion;

    private EditText etLogUsuario, etLogPassword;
    private boolean isModoRegistro = true;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Vinculación de vistas
        cbNuevoUsuario = findViewById(R.id.cbNuevoUsuario);
        cbLogueate = findViewById(R.id.cbLogueate);
        tvTituloPantalla = findViewById(R.id.tvTituloPantalla);
        btnHacerRegistro = findViewById(R.id.btnHacerRegistro);
        btnHacerLogin = findViewById(R.id.btnHacerLogin);
        containerRegistro = findViewById(R.id.containerRegistro);
        containerLogin = findViewById(R.id.containerLogin);

        etRegNombre = findViewById(R.id.etRegNombre);
        etRegDireccion = findViewById(R.id.etRegDireccion);
        etRegLocalidad = findViewById(R.id.etRegLocalidad);
        etRegTelefono = findViewById(R.id.etRegTelefono);
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPassword);
        etRegProvincia = findViewById(R.id.etRegProvincia);
        cbAceptoProteccion = findViewById(R.id.cbAceptoProteccion);

        etLogUsuario = findViewById(R.id.etLogUsuario);
        etLogPassword = findViewById(R.id.etLogPassword);


        // Listeners de selección de modo
        cbNuevoUsuario.setOnClickListener(v -> {
            if (cbNuevoUsuario.isChecked()) activarModoRegistro();
            else cbNuevoUsuario.setChecked(true);
        });

        cbLogueate.setOnClickListener(v -> {
            if (cbLogueate.isChecked()) activarModoLogin();
            else cbLogueate.setChecked(true);
        });

        // Botón Registro
        btnHacerRegistro.setOnClickListener(v -> {
            ejecutarRegistro();
        });

        // Botón Login
        btnHacerLogin.setOnClickListener(v -> {
            ejecutarLogin();
        });
        progressBar = findViewById(R.id.progressBar);
    }

    private void ejecutarRegistro() {
        // Validaciones
        if (etRegNombre.getText().toString().isEmpty() || etRegEmail.getText().toString().isEmpty()) {
            Toast.makeText(this, "Rellena los campos obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!cbAceptoProteccion.isChecked()) {
            Toast.makeText(this, "Acepta la protección de datos", Toast.LENGTH_SHORT).show();
            return;
        }
        mostrarCargando(true);
        // Configuración Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        // Crear objeto Usuario
        Cliente nuevo = new Cliente(
                etRegNombre.getText().toString(),
                etRegDireccion.getText().toString(),
                etRegLocalidad.getText().toString(),
                etRegProvincia.getText().toString(),
                etRegEmail.getText().toString(),
                etRegTelefono.getText().toString(),
                etRegPassword.getText().toString()
        );

        // Envío
        apiService.registrarUsuario(nuevo).enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, Response<Cliente> response) {

                mostrarCargando(false);

                if (response.isSuccessful()) {
                    Toast.makeText(LoginActivity.this, "¡Registrado en MySQL!", Toast.LENGTH_LONG).show();

                    limpiarFormulario();

                } else {
                    Toast.makeText(LoginActivity.this, "Error: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }
            private void limpiarFormulario(){
                etRegNombre.setText("");
                etRegDireccion.setText("");
                etRegLocalidad.setText("");
                etRegProvincia.setText("");
                etRegTelefono.setText("");
                etRegEmail.setText("");
                etRegPassword.setText("");

                cbAceptoProteccion.setChecked(false);

                etRegNombre.requestFocus();
            }
            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
                mostrarCargando(false);
                Toast.makeText(LoginActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void ejecutarLogin() {
        String email = etLogUsuario.getText().toString();
        String pass = etLogPassword.getText().toString();

        if (email.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Introduce tus credenciales", Toast.LENGTH_SHORT).show();
            return;
        }

        mostrarCargando(true);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ApiService apiService = retrofit.create(ApiService.class);

        // Creamos un objeto cliente solo con los datos necesarios para validar
        Cliente datosLogin = new Cliente();
        datosLogin.setEmail(email);
        datosLogin.setPassword(pass);

        apiService.loginUsuario(datosLogin).enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, Response<Cliente> response) {

                mostrarCargando(false);

                if (response.isSuccessful() && response.body() != null) {
                    Cliente c = response.body();
                    Toast.makeText(LoginActivity.this, "¡Bienvenido " + c.getNombre() + "!", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.putExtra("ID_CLIENTE", c.getIdCliente());
                    intent.putExtra("NOMBRE_CLIENTE", c.getNombre());
                    intent.putExtra("EMAIL", c.getEmail());
                    intent.putExtra("TELEFONO", c.getTelefono());
                    intent.putExtra("DIRECCION", c.getDireccion());

                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
               mostrarCargando(false);
                Toast.makeText(LoginActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void activarModoRegistro() {
        isModoRegistro = true;
        cbNuevoUsuario.setChecked(true);
        cbLogueate.setChecked(false);
        tvTituloPantalla.setText("Registro");
        containerRegistro.setVisibility(View.VISIBLE);
        containerLogin.setVisibility(View.GONE);
    }

    private void activarModoLogin() {
        isModoRegistro = false;
        cbNuevoUsuario.setChecked(false);
        cbLogueate.setChecked(true);
        tvTituloPantalla.setText("Login");
        containerRegistro.setVisibility(View.GONE);
        containerLogin.setVisibility(View.VISIBLE);
    }
    private void mostrarCargando(boolean cargando) {
        if (cargando) {
            progressBar.setVisibility(View.VISIBLE);
            btnHacerLogin.setEnabled(false);
            btnHacerRegistro.setEnabled(false);
        } else {
            progressBar.setVisibility(View.GONE);
            btnHacerLogin.setEnabled(true);
            btnHacerRegistro.setEnabled(true);
        }
    }
}