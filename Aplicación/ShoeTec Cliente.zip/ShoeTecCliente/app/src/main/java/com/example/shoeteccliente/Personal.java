package com.example.shoeteccliente;

public class Personal {

    // Constructor vacío corregido
    public Personal() {
    }

    private int id;
    private String nombre;
    private String rol;
    private String especialidad;

    // Getters y Setters (están perfectos)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
}