package com.example.shoeteccliente;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.shoeteccliente.R;
import com.example.shoeteccliente.HistorialPedido;
import java.util.List;

public class HistorialAdapter extends RecyclerView.Adapter<HistorialAdapter.HistorialViewHolder> {

    private List<HistorialPedido> listaHistorial;

    // Constructor: recibe la lista de estados del pedido
    public HistorialAdapter(List<HistorialPedido> listaHistorial) {
        this.listaHistorial = listaHistorial;
    }

    @NonNull
    @Override
    public HistorialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Enlazamos con el XML pequeño que creamos (item_historial)
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_historial, parent, false);
        return new HistorialViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistorialViewHolder holder, int position) {
        // Obtenemos el estado actual de la lista
        HistorialPedido historial = listaHistorial.get(position);

        // Ponemos el texto y la fecha en los TextViews
        holder.tvEstado.setText(historial.getEstado());
        holder.tvFecha.setText(historial.getFecha());
    }

    @Override
    public int getItemCount() {
        return listaHistorial != null ? listaHistorial.size() : 0;
    }

    // Clase interna para referenciar los elementos del XML item_historial
    public static class HistorialViewHolder extends RecyclerView.ViewHolder {
        TextView tvEstado, tvFecha;

        public HistorialViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEstado = itemView.findViewById(R.id.tvEstadoTexto);
            tvFecha = itemView.findViewById(R.id.tvFechaTexto);
        }
    }
}