package com.example.shoeteccliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvBienvenida, tvPerfilEmail, tvPerfilTelefono, tvNombreCabecera, tvPerfilDireccion;
    private Button btnCerrarSesion;
    private Button btnEditar;
    private LinearLayout btnServicios;
    private LinearLayout btnReparacion;
    private LinearLayout btnPedidos;
    private long idCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vinculación de vistas
        tvBienvenida = findViewById(R.id.tvBienvenida);
        tvPerfilEmail = findViewById(R.id.tvPerfilEmail);
        tvPerfilTelefono = findViewById(R.id.tvPerfilTelefono);
        tvNombreCabecera = findViewById(R.id.tvNombreCabecera);
        tvPerfilDireccion = findViewById(R.id.tvPerfilDireccion);
        btnEditar = findViewById(R.id.btnEditarPerfil);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        btnServicios = findViewById(R.id.btnServicios);
        btnReparacion = findViewById(R.id.btnReparacion);
        btnPedidos = findViewById(R.id.btnPedidos);

        // Recoger datos del Intent
        String nombre = getIntent().getStringExtra("NOMBRE_CLIENTE");
        String emailRecibido = getIntent().getStringExtra("EMAIL");
        String telfRecibido = getIntent().getStringExtra("TELEFONO");
        String direcRecibido = getIntent().getStringExtra("DIRECCION");
        this.idCliente = getIntent().getLongExtra("ID_CLIENTE", -1L);

        // Mostrar los datos
        if (nombre != null) {
            tvBienvenida.setText("¡Bienvenid@, " + nombre + "!");
            tvNombreCabecera.setText(nombre.toUpperCase());
        } else {
            tvNombreCabecera.setText("INVITADO");
        }

        if (emailRecibido != null) tvPerfilEmail.setText("Email: " + emailRecibido);
        if (telfRecibido != null) tvPerfilTelefono.setText("Teléfono: " + telfRecibido);
        if (direcRecibido != null) tvPerfilDireccion.setText("Dirección: " + direcRecibido);

        // Lógica del Botón Cerrar Sesión (DENTRO del Listener)
        if (btnCerrarSesion != null) {
            btnCerrarSesion.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                // Limpia el historial para que no pueda volver atrás al perfil
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        }
        // Lógica del Botón Servicios
        if (btnServicios != null) {
            btnServicios.setOnClickListener(v -> {

                Intent intent = new Intent(MainActivity.this, CatalogoActivity.class);
                startActivity(intent);
            });
        }
        // Lógica del Botón Editar
        if (btnEditar != null) {
            btnEditar.setOnClickListener(v -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                View viewInflada = getLayoutInflater().inflate(R.layout.dialog_editar_perfil, null);
                builder.setView(viewInflada);

                EditText etTel = viewInflada.findViewById(R.id.etEditarTelefono);
                EditText etDir = viewInflada.findViewById(R.id.etEditarDireccion);

                etTel.setText(tvPerfilTelefono.getText().toString().replace("Teléfono: ", ""));
                etDir.setText(tvPerfilDireccion.getText().toString().replace("Dirección: ", ""));

                String currentTel = tvPerfilTelefono.getText().toString().replace("Teléfono: ", "");
                String currentDir = tvPerfilDireccion.getText().toString().replace("Dirección: ", "");
                etTel.setText(currentTel);
                etDir.setText(currentDir);

                builder.setPositiveButton("Guardar", (dialog, which) -> {
                    actualizarDatosServidor(etTel.getText().toString(), etDir.getText().toString());
                });

                builder.setNegativeButton("Cancelar", null);
                builder.show();
            });
        }

        // Lógica del Botón Reparación
        if (btnReparacion != null) {
            btnReparacion.setOnClickListener(v -> {

                Intent intent = new Intent(MainActivity.this, ReparacionActivity.class);

                intent.putExtra("ID_CLIENTE", idCliente);
                intent.putExtra("NOMBRE_CLIENTE", nombre);
                intent.putExtra("DIRECCION_CLIENTE", direcRecibido);

                startActivity(intent);
            });
        }
        // Lógica del Botón Pedidos
        if (btnPedidos !=null) {
            btnPedidos.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, MisPedidosActivity.class);
                intent.putExtra("ID_CLIENTE", idCliente); // Pasamos el ID para saber de quién son los pedidos
                startActivity(intent);
            });
        }
        }
    private void actualizarDatosServidor(String tel, String dir) {

        if (idCliente == -1L) {
            Toast.makeText(this, "Error: No se recibió el ID del cliente", Toast.LENGTH_SHORT).show();
            return;
        }

        Cliente clienteEditado = new Cliente();
        clienteEditado.setIdCliente(this.idCliente);
        clienteEditado.setTelefono(tel);
        clienteEditado.setDireccion(dir);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService api = retrofit.create(ApiService.class);

        api.actualizarCliente(clienteEditado).enqueue(new Callback<Void>() {


            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    tvPerfilTelefono.setText("Teléfono: " + tel);
                    tvPerfilDireccion.setText("Dirección: " + dir);
                    Toast.makeText(MainActivity.this, "Datos actualizados correctamente", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Error al guardar en servidor", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Fallo de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
