package com.example.shoeteccliente;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ReparacionActivity extends AppCompatActivity {

    private EditText etNombre, etDireccion, etFecha, etObservaciones;
    private Spinner spinnerCalzado, spinnerServicio, spinnerHorario;
    private Button btnConfirmar;
    private String fechaSeleccionada = "";
    private ApiService apiService;
    private TextView tvPrecioTotal;
    private double precioCalculado = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reparacion);

        Button btnVolver = findViewById(R.id.btnVolverPerfil);
        btnVolver.setOnClickListener(v -> {
            // Simplemente cerramos esta actividad para volver a la anterior (MainActivity)
            finish();
        });

        // Recuperar ID del cliente
        long idCli = getIntent().getLongExtra("ID_CLIENTE", -1L);
        Toast.makeText(this, "DEBUG: El ID recibido es " + idCli, Toast.LENGTH_LONG).show();


        // Inicializar Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/") // Asegúrate de que termine en /
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(ApiService.class);

        // Vincular vistas y configurar
        vincularVistas();
        configurarSpinners();

        // Cargar datos del Intent (si vienen de la pantalla anterior)
        String nombreSurgido = getIntent().getStringExtra("NOMBRE_CLIENTE");
        String direccionSurgida = getIntent().getStringExtra("DIRECCION_CLIENTE");

        if (nombreSurgido != null) etNombre.setText(nombreSurgido);
        if (direccionSurgida != null) etDireccion.setText(direccionSurgida);

        // Listeners
        etFecha.setOnClickListener(v -> abrirCalendario());
        btnConfirmar.setOnClickListener(v -> validarYEnviar(idCli));
    }

    private void vincularVistas() {
        etNombre = findViewById(R.id.etNombreRecogida);
        etDireccion = findViewById(R.id.etDireccionRecogida);
        etFecha = findViewById(R.id.etFechaRecogida);
        etObservaciones = findViewById(R.id.etObservaciones);
        spinnerCalzado = findViewById(R.id.spinnerTipoCalzado);
        spinnerServicio = findViewById(R.id.spinnerServicioReparacion);
        spinnerHorario = findViewById(R.id.spinnerHorario);
        btnConfirmar = findViewById(R.id.btnConfirmarReparacion);
        tvPrecioTotal = findViewById(R.id.tvPrecioTotal);
    }

    private void configurarSpinners() {
        String[] opcionesCalzado = {"Zapatillas", "Zapatos de vestir", "Botas", "Sandalias", "Deportivo"};
        spinnerCalzado.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesCalzado));

        String[] opcionesServicio = {"Limpieza y Pulido", "Reemplazo de Suelas",
                "Costura", "Tratamiento del Color", "Colocación de Tapetas",
                "Cremallera y Hebillas", "Estirado", "Impermeabilización", "Modificaciones",
                "Cambio de Plantillas", "Reemplazo de Suelas de Botas"};
        spinnerServicio.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesServicio));

        spinnerServicio.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                actualizarPrecioVisual(); // Se ejecuta cada vez que el usuario elige un servicio
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        String[] opcionesHorario = {"Mañana (09:00 - 14:00)", "Tarde (16:00 - 20:00)"};
        spinnerHorario.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesHorario));
    }

    private void actualizarPrecioVisual() {
        String servicio = spinnerServicio.getSelectedItem().toString();

        switch (servicio) {
            case "Limpieza y Pulido":
                precioCalculado = 15.0;
                break;
            case "Reemplazo de Suelas":
                precioCalculado = 20.0;
                break;
            case "Costura":
                precioCalculado = 20.0;
                break;
            case "Tratamiento del Color":
                precioCalculado = 50.0;
                break;
            case "Colocación de Tapetas":
                precioCalculado = 15.0;
                break;
            case "Cremallera y Hebillas":
                precioCalculado = 15.0;
                break;
            case "Estirado":
                precioCalculado = 15.0;
                break;
            case "Impermeabilización":
                precioCalculado = 25.0;
                break;
            case "Modificaciones":
                precioCalculado = 40.0;
                break;
            case "Cambio de Plantillas":
                precioCalculado = 15.0;
                break;
            case "Reemplazo de Suelas de Botas":
                precioCalculado = 55.0;
                break;
            default:
                precioCalculado = 0.0;
                break;
        }

        tvPrecioTotal.setText("Total a pagar: " + precioCalculado + "€");
    }

    private void abrirCalendario() {
        final Calendar c = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, monthOfYear, dayOfMonth) -> {
// Dentro de tu DatePickerDialog
            fechaSeleccionada = year + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth);
            etFecha.setText(fechaSeleccionada);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void validarYEnviar(long idCli) {
        if (fechaSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor, elige una fecha de recogida", Toast.LENGTH_SHORT).show();
            return;
        }
        int idServicioSeleccionado = spinnerServicio.getSelectedItemPosition() + 1;

        Pedido nuevoPedido = new Pedido();

        nuevoPedido.setId_cliente((int) idCli);

        nuevoPedido.setId_servicio(idServicioSeleccionado);

        nuevoPedido.setDireccion_Entrega(etDireccion.getText().toString());
        nuevoPedido.setTipo_Calzado(spinnerCalzado.getSelectedItem().toString());
        nuevoPedido.setServicio(spinnerServicio.getSelectedItem().toString());
        nuevoPedido.setFecha_Recogida(fechaSeleccionada);
        nuevoPedido.setFranja_Horaria(spinnerHorario.getSelectedItem().toString());
        nuevoPedido.setObservaciones(etObservaciones.getText().toString());
        nuevoPedido.setPrecio_total(this.precioCalculado);
        nuevoPedido.setEstado("PENDIENTE");

        apiService.guardarPedido(nuevoPedido).enqueue(new Callback<Pedido>() {

            @Override
            public void onResponse(Call<Pedido> call, Response<Pedido> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ReparacionActivity.this, "¡Pedido enviado con éxito!", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(ReparacionActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(ReparacionActivity.this, "Error del servidor: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Pedido> call, Throwable t) {
                // --- AJUSTE: Añadimos el onFailure para que no de error si falla el internet ---
                Toast.makeText(ReparacionActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}