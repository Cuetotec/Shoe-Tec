package com.example.shoeteccliente;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
public interface ApiService {
    @GET("personal")
    Call<List<Personal>> getPersonal();
    @POST("clientes")
    Call<Cliente> guardarCliente(@Body Cliente cliente);
    @POST("clientes/actualizar")
    Call<Void> actualizarCliente(@Body Cliente cliente);
    @POST("clientes/registro")
    Call<Cliente> registrarUsuario(@Body Cliente usuario);
    @POST("clientes/login")
    Call<Cliente> loginUsuario(@Body Cliente datosLogin);
    @GET("servicios")
    Call<List<Servicio>> obtenerCatalogo();
    @POST("pedidos/guardar")
    Call<Pedido> guardarPedido(@Body Pedido pedido);
    @GET("pedidos/cliente/{id}")
    Call<List<Pedido>> obtenerPedidosPorCliente(@Path("id") long idCliente);
}
