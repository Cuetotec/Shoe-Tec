package com.example.shoeteccliente;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MisPedidosActivity extends AppCompatActivity {

    private SeguimientoAdapter adapter;
    private RecyclerView rvSeguimiento;
    private TextView tvServicioPrincipal, tvPrecioTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mis_pedidos);

        // Vinculación de vistas
        tvServicioPrincipal = findViewById(R.id.tvNombreServicio);
        tvPrecioTotal = findViewById(R.id.tvPrecioTotal);
        rvSeguimiento = findViewById(R.id.rvSeguimiento);
        rvSeguimiento.setLayoutManager(new LinearLayoutManager(this));

        adapter = new SeguimientoAdapter(new ArrayList<>());
        rvSeguimiento.setAdapter(adapter);
        findViewById(R.id.btnVolverPerfilDesdeSeguimiento).setOnClickListener(v -> finish());

        long idCli = getIntent().getLongExtra("ID_CLIENTE", -1L);
        if (idCli != -1L) {
            cargarDatosPedido(idCli);
        } else {
            Toast.makeText(this, "Error: No se encontró el ID del cliente", Toast.LENGTH_SHORT).show();
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        findViewById(R.id.btnVolverPerfilDesdeSeguimiento).setOnClickListener(v -> finish());
    }

    private void cargarDatosPedido(long idCli) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService api = retrofit.create(ApiService.class);

        api.obtenerPedidosPorCliente(idCli).enqueue(new Callback<List<Pedido>>() {
            @Override
            public void onResponse(Call<List<Pedido>> call, Response<List<Pedido>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Pedido> pedidosReales = response.body();

                    if (!pedidosReales.isEmpty()) {
                        Pedido primerPedido = pedidosReales.get(0);
                        List<HistorialPedido> elHistorial = primerPedido.getHistorial();
                        if (elHistorial == null) {
                            elHistorial = new ArrayList<>();
                        }

                        tvServicioPrincipal.setText(primerPedido.getServicio());
                        tvPrecioTotal.setText(String.format("%.2f€", primerPedido.getPrecio_total()));

                        // Configuramos la lista
                        adapter = new SeguimientoAdapter(elHistorial);
                        rvSeguimiento.setAdapter(adapter);


                    } else {
                        android.util.Log.e("PRUEBA", "Respuesta vacía o error en el servidor");
                        Toast.makeText(MisPedidosActivity.this, "No tienes pedidos activos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Pedido>> call, Throwable t) {
                android.util.Log.e("PRUEBA", "Error de conexión: " + t.getMessage());
                Toast.makeText(MisPedidosActivity.this, "Error al cargar pedidos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}