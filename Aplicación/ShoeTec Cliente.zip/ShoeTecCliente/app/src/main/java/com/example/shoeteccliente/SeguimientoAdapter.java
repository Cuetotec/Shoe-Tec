package com.example.shoeteccliente;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SeguimientoAdapter extends RecyclerView.Adapter<SeguimientoAdapter.SeguimientoViewHolder> {

    private List<HistorialPedido> listaHistorial;

    public SeguimientoAdapter(List<HistorialPedido> listaHistorial) {
        this.listaHistorial = listaHistorial;

        if (listaHistorial != null) {
            android.util.Log.d("DEBUG_ADAPTER", "Constructor: Recibidos " + listaHistorial.size() + " elementos");
        } else {
            android.util.Log.d("DEBUG_ADAPTER", "Constructor: ¡La lista es NULL!");
        }    }

    @NonNull
    @Override
    public SeguimientoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Asegúrate de que el XML se llame item_seguimiento
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_seguimiento, parent, false);
        return new SeguimientoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SeguimientoViewHolder holder, int position) {
        if (listaHistorial != null && position < listaHistorial.size()) {
            HistorialPedido p = listaHistorial.get(position);

            holder.tvEstado.setText("Estado: " + p.getEstado());
            holder.tvEstado.setTextColor(android.graphics.Color.BLACK);
            holder.tvEstado.setAlpha(1.0f);

            holder.tvFecha.setText("Fecha: " + p.getFecha());
            holder.tvFecha.setTextColor(android.graphics.Color.DKGRAY);

            holder.viewLineTop.setVisibility(View.VISIBLE);
            holder.viewLineBottom.setVisibility(View.VISIBLE);
            holder.viewLineTop.setBackgroundColor(android.graphics.Color.RED);

            if (p.getCompleto()) {

                holder.ivCheck.setImageResource(R.drawable.check_circle);
                holder.ivCheck.setColorFilter(ContextCompat.getColor(holder.itemView.getContext(), R.color.brown_shoe));
                holder.tvEstado.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.marron_oscuro));
                holder.tvEstado.setAlpha(1.0f);
                holder.viewLineTop.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.marron_oscuro));
                holder.viewLineBottom.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.marron_oscuro));
            } else {
                // ESTADO PENDIENTE (Grisáceo)
                holder.ivCheck.setImageResource(R.drawable.circle_outline);
                holder.ivCheck.setColorFilter(ContextCompat.getColor(holder.itemView.getContext(), R.color.marron_claro));
                holder.tvEstado.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.marron_claro));
                holder.tvEstado.setAlpha(0.6f);
                holder.viewLineTop.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.linea_seguimiento));
                holder.viewLineBottom.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.linea_seguimiento));
            }

            // --- CONEXIÓN DE LA LÍNEA ---
            // Si es el primero, no hay línea hacia arriba
            holder.viewLineTop.setVisibility(position == 0 ? View.INVISIBLE : View.VISIBLE);
            // Si es el último, no hay línea hacia abajo
            holder.viewLineBottom.setVisibility(position == listaHistorial.size() - 1 ? View.INVISIBLE : View.VISIBLE);
        }
    }
    @Override
    public int getItemCount() {
        return (listaHistorial != null) ? listaHistorial.size() : 0;

    }

    public static class SeguimientoViewHolder extends RecyclerView.ViewHolder {

        TextView tvFecha, tvEstado;
        ImageView ivCheck;
        View viewLineTop, viewLineBottom;

        public SeguimientoViewHolder(@NonNull View itemView) {
            super(itemView);

            tvFecha = itemView.findViewById(R.id.tvFechaTexto);
            tvEstado = itemView.findViewById(R.id.tvEstadoTexto);
            ivCheck = itemView.findViewById(R.id.ivCheckEstado);

            viewLineTop = itemView.findViewById(R.id.viewLineTop);
            viewLineBottom = itemView.findViewById(R.id.viewLineBottom);
        }
    }
}