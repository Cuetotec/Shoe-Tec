package com.example.shoeteccliente;

public class EstadoPedido {
    private String titulo;
    private String fecha;
    private int imagenResId; // Para el icono (camión, caja, etc.)

    public EstadoPedido(String titulo, String fecha, int imagenResId) {
        this.titulo = titulo;
        this.fecha = fecha;
        this.imagenResId = imagenResId;
    }

    // Getters
    public String getTitulo() { return titulo; }
    public String getFecha() { return fecha; }
    public int getImagenResId() { return imagenResId; }
}
