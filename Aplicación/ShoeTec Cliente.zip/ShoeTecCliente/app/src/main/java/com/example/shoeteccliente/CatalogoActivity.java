package com.example.shoeteccliente;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CatalogoActivity extends AppCompatActivity {

    private RecyclerView rvCatalogo;
    private ServicioAdapter adapter;
    private Button btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogo);

        rvCatalogo = findViewById(R.id.rvCatalogo);
        Button btnVolver = findViewById(R.id.btnVolverMain);

        rvCatalogo.setLayoutManager(new LinearLayoutManager(this));

        obtenerDatosServidor();

        // Lógica del botón volver
        if (btnVolver != null) {
            btnVolver.setOnClickListener(v -> {
                finish();
            });
        }
    }
        private void obtenerDatosServidor() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.136:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService api = retrofit.create(ApiService.class);

        Call<List<Servicio>> call = api.obtenerCatalogo();

        call.enqueue(new Callback<List<Servicio>>() {
            @Override
            public void onResponse(Call<List<Servicio>> call, Response<List<Servicio>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter = new ServicioAdapter(response.body());
                    rvCatalogo.setAdapter(adapter);
                } else {
                    Toast.makeText(CatalogoActivity.this, "Error en la respuesta", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Servicio>> call, Throwable t) {
                Toast.makeText(CatalogoActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}