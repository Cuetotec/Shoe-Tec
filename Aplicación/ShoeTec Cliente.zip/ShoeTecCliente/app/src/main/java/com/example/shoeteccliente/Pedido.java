package com.example.shoeteccliente;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import java.util.ArrayList;
public class Pedido {
    @SerializedName("id_servicio")
    private Integer id_servicio;
    @SerializedName("id_cliente")
    private Integer id_cliente;
    @SerializedName("direccion_entrega")
    private String direccion_entrega;
    @SerializedName("tipo_calzado")
    private String tipo_calzado;
    @SerializedName("servicio")
    private String servicio;
    @SerializedName("estado")
    private String estado;
    @SerializedName("fecha_recogida")
    private String fecha_recogida;
    @SerializedName("franja_horaria")
    private String franja_horaria;
    @SerializedName("observaciones")
    private String observaciones;
    @SerializedName("precio_total")
    private double precio_total;
    @SerializedName("id_pedido")
    private Long id_pedido;
    @SerializedName("historial")
    private List<HistorialPedido> historial;

    // Getters corregidos para que el Adapter los encuentre sin errores
    public Integer getId_servicio() {
        return id_servicio;
    }
    public String getServicio() {
        return servicio;
    }

    public String getEstado() {
        return estado;
    }

    public String getFecha_Recogida() {
        return fecha_recogida;
    }

    public String getFranja_Horaria() {
        return franja_horaria;
    }

    public double getPrecio_total() {
        return precio_total;
    }

    public Integer getId_cliente() {
        return id_cliente;
    }

    public String getDireccion_entrega() {
        return direccion_entrega;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public String getTipo_calzado() {
        return tipo_calzado;
    }

    public Long getId_pedido() {
        return id_pedido;
    }

    public List<HistorialPedido> getHistorial() {
        return historial;
    }
    public void setId_servicio(Integer id_servicio) {
        this.id_servicio = id_servicio;
    }
    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setFecha_Recogida(String fecha_recogida) {
        this.fecha_recogida = fecha_recogida;
    }

    public void setFranja_Horaria(String franja_horaria) {
        this.franja_horaria = franja_horaria;
    }

    public void setPrecio_total(double precio_total) {
        this.precio_total = precio_total;
    }

    public void setId_cliente(Integer id_cliente) {
        this.id_cliente = id_cliente;
    }

    public void setDireccion_Entrega(String direccion_entrega) {
        this.direccion_entrega = direccion_entrega;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setTipo_Calzado(String tipo_calzado) {
        this.tipo_calzado = tipo_calzado;
    }
    public void setId_pedido (Long id_pedido){
        this.id_pedido = id_pedido;
    }
    public void setHistorial (List<HistorialPedido> historial){
        this.historial = historial;
    }
}
