package com.example.shoeteccliente;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class ServicioAdapter extends RecyclerView.Adapter<ServicioAdapter.ServicioViewHolder> {

    private List<Servicio> listaServicios;

    public ServicioAdapter(List<Servicio> listaServicios) {
        this.listaServicios = listaServicios;
}

    @NonNull
    @Override
    public ServicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Aquí usamos el diseño de la fila (item_servicio.xml)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_servicio, parent, false);
        return new ServicioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServicioViewHolder holder, int position) {
        android.util.Log.d("ADAPTER_TEST", "Dibujando posición: " + position);
        Servicio s = listaServicios.get(position);
        holder.tvDesc.setText(s.getDescripcion());
        holder.tvPrecio.setText(s.getPrecio() + " €");
    }

    @Override
    public int getItemCount() {
        return listaServicios.size();
    }

    public static class ServicioViewHolder extends RecyclerView.ViewHolder {
        TextView tvDesc, tvPrecio;

        public ServicioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDesc = itemView.findViewById(R.id.tvServicioDesc);
            tvPrecio = itemView.findViewById(R.id.tvServicioPrecio);
        }
    }
}

