package com.example.shoeteccliente;

import com.google.gson.annotations.SerializedName;

public class Servicio {

    public Servicio() {}
    @SerializedName("id_servicios")
    private Integer id_service;
    @SerializedName("descripcion")
    private String descripcion;
    @SerializedName("precio")
    private double precio;

    public Servicio(String descripcion, double precio) {
        this.id_service = null;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public Integer getIdServicios() { return id_service; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }

    public void setIdServicios(Integer idServicios) { this.id_service = idServicios; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setPrecio(double precio) { this.precio = precio; }

}

